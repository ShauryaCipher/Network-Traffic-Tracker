Network Traffic Analyzer
=======================

Installation Instructions:

1. Ensure you have Python 3.8 or newer installed
2. Install the required dependencies:
   pip install customtkinter pandas matplotlib networkx kamene psutil

3. Run the application:
   - Windows: Double-click run_analyzer.bat
   - Linux/Mac: In terminal, run: sudo ./run_analyzer.sh

Note: This application requires administrator/root privileges for packet capture.
