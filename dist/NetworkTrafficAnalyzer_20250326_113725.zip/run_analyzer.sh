#!/bin/bash
echo 'Starting Network Traffic Analyzer...'
echo 'This application requires root privileges for packet capture.'
echo 'If you are not seeing any traffic, please restart with sudo.'
python3 desktop_app.py
