#!/bin/bash
echo "Starting Network Traffic Analyzer..."
python3 desktop_app.py
