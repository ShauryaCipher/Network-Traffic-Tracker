Network Traffic Analyzer
=======================

This package contains the Network Traffic Analyzer application.

Requirements:
- Python 3.8 or higher
- Required Python packages (install using pip):
  pip install customtkinter pandas matplotlib networkx kamene psutil

To run the application:
1. Extract all files to a directory
2. Install the required packages
3. Run the desktop application:
   python desktop_app.py

Note: Network packet capture requires administrator/root privileges.
On Windows: Run Command Prompt or PowerShell as Administrator
On Linux/Mac: Use sudo python desktop_app.py

For more information, see the included README.md file.
